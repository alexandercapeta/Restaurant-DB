def recommend(file, price, cuisines_list):
    """(file open for reading, str, list of str) -> list of [int, str] list

    Find restaurants in file that are priced according to price and that are
    tagged with any of the items in cuisines_list.  Return a list of lists of
    the form [rating%, restaurant name], sorted by rating%.
    """

    # Read the file and build the data structures.
    # - a dict of {restaurant name: rating%}
    # - a dict of {price: list of restaurant names}
    # - a dict of {cusine: list of restaurant names}
    name_to_rating, price_to_names, cuisine_to_names = read_restaurants(file)


    # Look for price or cuisines first?
    # Price: look up the list of restaurant names for the requested price.
    names_matching_price = price_to_names[price]

    # Now we have a list of restaurants in the right price range.
    # Need a new list of restaurants that serve one of the cuisines.
    names_final = filter_by_cuisine(names_matching_price, cuisine_to_names, cuisines_list)

    # Now we have a list of restaurants that are in the right price range and serve the requested cuisine.
    # Need to look at ratings and sort this list.
    result = build_rating_list(name_to_rating, names_final)

    # We're done!  Return that sorted list.
    return result

def build_rating_list(name_to_rating, names_final):
    """ (dict of {str: int}, list of str) -> list of list of [int, str]

    Return a list of [rating%, restaurant name], sorted by rating%

    >>> name_to_rating = {'Georgie Porgie': 87,
     'Queen St. Cafe': 82,
     'Dumplings R Us': 71,
     'Mexican Grill': 85,
     'Deep Fried Everything': 52}
    >>> names = ['Queen St. Cafe', 'Dumplings R Us']
    [[82, 'Queen St. Cafe'], [71, 'Dumplings R Us']]
    """
    restaurants = []
    for restaurant in names_final:
        if restaurant in name_to_rating:
            restaurants.append(name_to_rating[restaurant], restaurant)
    restaurant.sort(reverse=True)
    

def filter_by_cuisine(names_matching_price, cuisine_to_names, cuisines_list):
    """ (list of str, dict of {str: list of str}, list of str) -> list of str

    >>> names = ['Queen St. Cafe', 'Dumplings R Us', 'Deep Fried Everything']
    >>> cuis = 'Canadian': ['Georgie Porgie'],
     'Pub Food': ['Georgie Porgie', 'Deep Fried Everything'],
     'Malaysian': ['Queen St. Cafe'],
     'Thai': ['Queen St. Cafe'],
     'Chinese': ['Dumplings R Us'],
     'Mexican': ['Mexican Grill']}
    >>> cuisines = ['Chinese', 'Thai']
    >>> filter_by_cuisine(names, cuis, cuisines)
    ['Queen St. Cafe', 'Dumplings R Us']
    """
    list_of_restaurants = []

    """Check each item provided in the Cuisine list provided by the customer
    If that item is a key in the cuisine_to_name dictionary then the dictionary
    is iterated over in order to access the list of all restaurants under that
    key. The restaurant is then appended to list_of_restaurants if not already
    appended.
    """
    for item in cuisines_list:
        if item in cuisine_to_names:
            for cuisine in cuisine_to_names[item]:
                if cuisine not in list_of_restaurants:
                    list_of_restaurants.append(cuisine)

    return list_of_restaurants



def read_restaurants(file):
    """file -> dictionaries
    name_to_rating = {}
    price_to_names = {'$': [], '$$': [], '$$$': [], '$$$$': []}
    cuisine_to_names = {}

    Reading from a file and using the data to complete the dictionaries
    """
    name_to_rating = {}
    price_to_names = {'$': [], '$$': [], '$$$': [], '$$$$': []}
    cuisine_to_names = {}
    
    g = open(file, mode='rt', encoding='utf-8')
    reference = []
    for line in g:
        reference.append(line.strip())

    '''Deletes elements that are empty strings'''
    for item in reference:
        if item == '':
            reference.remove('')

    '''Creates multiple inner lists with 4 items each
    [['Queen St. Cafe', '82%', '$', 'Malaysian,Thai'],.....]
    '''
    chunk = [reference[x: x+4] for x in range(0, len(reference), 4)]

    for item in chunk:
        '''Creating the name_to_rating dictionary
        Assigns the Name of restaurant as the key and the rating as the value
        '''
        name_to_rating[item[0]] = item[1].strip('%')

        '''Creating the price_to_names dictionary
        Assignt the price range to the names of the restaurant by checking
        the price of each inner list and then assigning the price as the keys
        and the names as the values'''
        if item[2] == '$':
            lst = price_to_names['$']
            lst.append(item[0])
        elif item[2] == '$$':
            lst = price_to_names['$$']
            lst.append(item[0])
        elif item[2] == '$$$':
            lst = price_to_names['$$$']
            lst.append(item[0])
        elif item[2] == '$$$$':
            lst = price_to_names['$$$$']
            lst.append(item[0])
        '''Creating the cuisine_to_name dictionary
        Splitting the elements of item[3] and creating a list. Then running
        through them using a for loop assigning item1 as the keys and item[0]
        as the values.'''
        lst_cuisines = item[3].split(',')
        for item1 in lst_cuisines:
                cuisine_to_names[item1] = item[0]

    return (name_to_rating, price_to_names, cuisine_to_names)
